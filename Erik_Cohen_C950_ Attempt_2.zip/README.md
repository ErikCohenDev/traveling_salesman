# traveling_salesman
A Traveling Salesman Solution in Python
